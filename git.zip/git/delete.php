<?php 

include "config.php"; 

if (isset($_GET['id'])) {

    $user_id = $_GET['id'];

    $sql = "DELETE FROM `user_reg` WHERE `id`='$user_id'";

     $result = $conn->query($sql);

     if ($result == TRUE) {

        echo "Record deleted successfully.";

    }else{

        echo "Error:" . $sql . "<br>" . $conn->error;

    }

} 

?>


<!-- deladd-->

<?php



include('config.php');

if(isset($_POST["id"]))
{
 $query = "DELETE FROM tbl_name WHERE id = '".$_POST['id']."'";
 $statement = $connect->prepare($query);
 $statement->execute();
}


?>
